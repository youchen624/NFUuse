module RTL(A, B, C, D, OUT);
input A, B, C, D;
output OUT;
reg OUT;
always @(A or B or C or D)
begin
	if(A & B & ~D)
		OUT = C;
	else if(A & D & ~C)
		OUT = B;
	else
		OUT = 0;
end

endmodule
