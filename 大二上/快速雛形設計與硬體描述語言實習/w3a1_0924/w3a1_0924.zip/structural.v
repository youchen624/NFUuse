module structural(A, B, C, D, OUT);
input A, B, C, D;
output OUT;
wire wd40;

	assign wd40 = C ^ D;
	assign OUT = wd40 & A & B;
endmodule
