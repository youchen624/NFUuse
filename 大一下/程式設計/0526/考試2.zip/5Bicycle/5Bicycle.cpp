#include <iostream>
#include <string>

using namespace std;

class Component {
private:
    string id;
    double cost;
public:
    Component(string n, double c) {
        id = n;
        cost = c;
    };
    double getcost() {
        return cost;
    };
};
class Frame : public Component {
public:
    Frame(string n, string t, double c) : Component(n, c) {
        type = t; // <?>
    };
private:
    string type;
};
class Wheel : public Component {
public:
    Wheel(string n, int s, double c) : Component(n, c) {
        size = s;
    }
private:
    int size;
};
class Bicycle {
public:
    static int count;
    Bicycle(Wheel w1, Frame f1) : f(f1), w(w1) {
        Bicycle::count++; // <?>
    };
    Bicycle(string n, int s, double c, Frame f1) : Bicycle(Wheel(n, s, c), f1) {};//f(f1) : w(n, s, c){};// <?>
    ~Bicycle() { Bicycle::count--; }; // <?>
    void changeWheel(Wheel w2) { w = w2; };
    void changeFrame(Frame f2) { f = f2; };
    double getcost() {
        return 500 + w.getcost() + f.getcost();
        return 0; // <?>
    }
private:
    Wheel w;
    Frame f;
};

int Bicycle::count = 0;

int main() {
    Wheel w1("16�T", 16, 2000);
    Wheel w2("20�T", 20, 3000);
    Frame f1("Giant", "iron", 2000);
    Frame f2("Merida", "iron", 3000);
    Frame f3("Argon 18", "alloy", 5000);
    Bicycle b1(w1, f1);
    cout << "�Ĥ@�x���欰:" << b1.getcost() << endl;
    Bicycle b2(w2, f1);
    cout << "�ĤG�x���欰:" << b2.getcost() << endl;
    Bicycle b3("�ۿ�", 22, 6000, f1);
    cout << "�ĤT�x���欰:" << b3.getcost() << endl;

    b1.changeWheel(w2);
    cout << "�Ĥ@�x�����l�᪺���欰:" << b1.getcost() << endl;
    cout << "�ثe�`�@�դF:" << Bicycle::count << "�x�p�P\n";
    return 0;
};