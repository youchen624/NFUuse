#include <iostream>
#define PI 3.14
using namespace std;

class Circle {
public:
    Circle(double r_ = 0) : r(r_) {};
    double area() {
        return (double)PI * r * r;
    };
    double get_R() {
        return r;
    };
protected:
    double r;
};
class inheritance_cylinder : public Circle {
public:
    inheritance_cylinder(double r_ = 0, double h_ = 0) : Circle(r_), h(h_) {};
    double area() {
        return Circle::area() * 2 + (double)2 * PI * r * h;
    };
    double vol() {
        return (double)PI * r * r * h;
    };
private:
    double h;
};
class composition_cylinder {
public:
    composition_cylinder(double r_, double h_) : c(r_), h(h_) {};
    double area() {
        return c.area() * 2 + (double)2 * PI * c.get_R() * h;
    };
    double vol() {
        return (double)PI * c.get_R() * c.get_R() * h;
    };
private:
    Circle c;
    double h;
};

int main() {
    double r, h;
    printf("�п�J��W�餧�b�|�P���G");
    cin >> r >> h; // 10 5
    inheritance_cylinder a(r, h);
    cout << "��W�骫�󭱿n���G" << a.area() << endl;
    composition_cylinder b(r, h);
    cout << "��W�骫�󭱿n���G" << b.area() << endl;
    return 0;
};