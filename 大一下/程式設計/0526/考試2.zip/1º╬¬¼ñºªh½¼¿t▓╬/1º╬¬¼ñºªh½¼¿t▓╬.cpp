#include <iostream>
#include <math.h>
#include <string>
#define PI 3.14
using namespace std;

class Shape {
public:
	Shape(string s = "", double r_ = 0, double h_ = 0, double a_ = 0) : name(s), r(r_), h(h_), a(a_) {};
	virtual void printname() {
		cout << name << endl;
	};
	virtual double area() = 0;
	virtual double volume() = 0;
protected:
	string name;
	double r, h, a;
};
class Cylinder : public Shape {
public:
	Cylinder(string s = "", double r_ = 0, double h_ = 0) : Shape(s, r_, h_) {};
	double area() {
		return (double)PI * r * r + (double)2 * PI * r * h;
	};
	double volume() {
		return (double)PI * r * r * h;
	};
private:
};
class Ball : public Shape {
public:
	Ball(string s = "", double r_ = 0) : Shape(s, r_) {};
	double area() {
		return (double)4 * PI * r * r;
	};
	double volume() {
		return (double)4 / 3 * PI * r * r * r;
	};
private:
};
class Pyramid : public Shape {
public:
	Pyramid(string s = "", double a_ = 0, double h_ = 0) : Shape(s, 0, h_, a_) {};
	double area() {
		return (double)a * a + 2 * a * sqrt((a / 2) * (a / 2) + h * h);
	};
	double volume() {
		return (double)1 / 3 * a * a * h;
	};
private:
};
class Cube : public Shape {
public:
	Cube(string s = "", double a_ = 0) : Shape(s, 0, 0, a_) {};
	double area() {
		return (double)6 * a * a;
	};
	double volume() {
		return (double)a * a * a;
	};
private:
};;

int main() {
	Shape* ptr[4];
	Ball a_ball("a_ball", 10);
	Cylinder a_cylinder("a_cylinder", 10, 5);
	Cube a_cube("a_cube", 10);
	Pyramid a_pyramid("a_pyramid", 10, 5);
	ptr[0] = &a_ball; ptr[1] = &a_cylinder; ptr[2] = &a_cube; ptr[3] = &a_pyramid;
	int i;
	for (i = 0; i < 4; i++) {
		ptr[i]->printname(); cout << ptr[i]->area() << endl;
		cout << ptr[i]->volume() << endl; cout << endl;
	}
	return 0;
};