#include <iostream>
using namespace std;

template <typename T>
void exchange(T& x, T& y) {
    T t = x;
    x = y;
    y = t;
};

int main() {
    int a = 2, b = 3;
    exchange<int>(a, b);
    cout << "after exchange: a=" << a << ", b=" << b << endl; // 3 2
    double c = 3.5, d = 6.34;
    exchange<double>(c, d);
    cout << "after exchange: c=" << c << ", d=" << d << endl; // 6.34 3.5
    return 0;
};