-- Copyright (C) 1991-2015 Altera Corporation. All rights reserved.
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, the Altera Quartus II License Agreement,
-- the Altera MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Altera and sold by Altera or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 15.0.0 Build 145 04/22/2015 SJ Full Version"

-- DATE "03/04/2025 15:18:18"

-- 
-- Device: Altera 5CEBA4F23C7 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA_LNSIM;
LIBRARY CYCLONEV;
LIBRARY IEEE;
USE ALTERA_LNSIM.ALTERA_LNSIM_COMPONENTS.ALL;
USE CYCLONEV.CYCLONEV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	week3blocks IS
    PORT (
	\OUT\ : OUT std_logic;
	xand : IN std_logic;
	yand : IN std_logic;
	OUT3 : OUT std_logic;
	xnand : IN std_logic;
	ynand : IN std_logic;
	OUT4 : OUT std_logic;
	xxnor : IN std_logic;
	yxnor : IN std_logic
	);
END week3blocks;

-- Design Ports Information
-- OUT	=>  Location: PIN_AA2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- OUT3	=>  Location: PIN_AA1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- OUT4	=>  Location: PIN_W2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- xand	=>  Location: PIN_U13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- yand	=>  Location: PIN_V13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- xnand	=>  Location: PIN_T13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ynand	=>  Location: PIN_T12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- xxnor	=>  Location: PIN_AA15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- yxnor	=>  Location: PIN_AB15,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF week3blocks IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \ww_OUT\ : std_logic;
SIGNAL ww_xand : std_logic;
SIGNAL ww_yand : std_logic;
SIGNAL ww_OUT3 : std_logic;
SIGNAL ww_xnand : std_logic;
SIGNAL ww_ynand : std_logic;
SIGNAL ww_OUT4 : std_logic;
SIGNAL ww_xxnor : std_logic;
SIGNAL ww_yxnor : std_logic;
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \xand~input_o\ : std_logic;
SIGNAL \yand~input_o\ : std_logic;
SIGNAL \inst|inst~combout\ : std_logic;
SIGNAL \xnand~input_o\ : std_logic;
SIGNAL \ynand~input_o\ : std_logic;
SIGNAL \inst1|inst2~combout\ : std_logic;
SIGNAL \xxnor~input_o\ : std_logic;
SIGNAL \yxnor~input_o\ : std_logic;
SIGNAL \inst2|inst1|inst4~0_combout\ : std_logic;
SIGNAL \ALT_INV_yxnor~input_o\ : std_logic;
SIGNAL \ALT_INV_xxnor~input_o\ : std_logic;
SIGNAL \ALT_INV_ynand~input_o\ : std_logic;
SIGNAL \ALT_INV_xnand~input_o\ : std_logic;
SIGNAL \ALT_INV_yand~input_o\ : std_logic;
SIGNAL \ALT_INV_xand~input_o\ : std_logic;
SIGNAL \inst2|inst1|ALT_INV_inst4~0_combout\ : std_logic;
SIGNAL \inst|ALT_INV_inst~combout\ : std_logic;

BEGIN

\OUT\ <= \ww_OUT\;
ww_xand <= xand;
ww_yand <= yand;
OUT3 <= ww_OUT3;
ww_xnand <= xnand;
ww_ynand <= ynand;
OUT4 <= ww_OUT4;
ww_xxnor <= xxnor;
ww_yxnor <= yxnor;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
\ALT_INV_yxnor~input_o\ <= NOT \yxnor~input_o\;
\ALT_INV_xxnor~input_o\ <= NOT \xxnor~input_o\;
\ALT_INV_ynand~input_o\ <= NOT \ynand~input_o\;
\ALT_INV_xnand~input_o\ <= NOT \xnand~input_o\;
\ALT_INV_yand~input_o\ <= NOT \yand~input_o\;
\ALT_INV_xand~input_o\ <= NOT \xand~input_o\;
\inst2|inst1|ALT_INV_inst4~0_combout\ <= NOT \inst2|inst1|inst4~0_combout\;
\inst|ALT_INV_inst~combout\ <= NOT \inst|inst~combout\;

-- Location: IOOBUF_X0_Y18_N79
\OUT~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|ALT_INV_inst~combout\,
	devoe => ww_devoe,
	o => \ww_OUT\);

-- Location: IOOBUF_X0_Y18_N96
\OUT3~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|inst2~combout\,
	devoe => ww_devoe,
	o => ww_OUT3);

-- Location: IOOBUF_X0_Y18_N62
\OUT4~output\ : cyclonev_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false",
	shift_series_termination_control => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|inst1|ALT_INV_inst4~0_combout\,
	devoe => ww_devoe,
	o => ww_OUT4);

-- Location: IOIBUF_X33_Y0_N41
\xand~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_xand,
	o => \xand~input_o\);

-- Location: IOIBUF_X33_Y0_N58
\yand~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_yand,
	o => \yand~input_o\);

-- Location: LABCELL_X32_Y2_N30
\inst|inst\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst|inst~combout\ = ( \yand~input_o\ & ( !\xand~input_o\ ) ) # ( !\yand~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111111001100110011001100110011001100",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datab => \ALT_INV_xand~input_o\,
	dataf => \ALT_INV_yand~input_o\,
	combout => \inst|inst~combout\);

-- Location: IOIBUF_X34_Y0_N1
\xnand~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_xnand,
	o => \xnand~input_o\);

-- Location: IOIBUF_X34_Y0_N18
\ynand~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_ynand,
	o => \ynand~input_o\);

-- Location: MLABCELL_X34_Y2_N33
\inst1|inst2\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst1|inst2~combout\ = ( \ynand~input_o\ & ( !\xnand~input_o\ ) ) # ( !\ynand~input_o\ )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "1111111111111111111111111111111111110000111100001111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \ALT_INV_xnand~input_o\,
	dataf => \ALT_INV_ynand~input_o\,
	combout => \inst1|inst2~combout\);

-- Location: IOIBUF_X36_Y0_N35
\xxnor~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_xxnor,
	o => \xxnor~input_o\);

-- Location: IOIBUF_X36_Y0_N52
\yxnor~input\ : cyclonev_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_yxnor,
	o => \yxnor~input_o\);

-- Location: LABCELL_X36_Y2_N30
\inst2|inst1|inst4~0\ : cyclonev_lcell_comb
-- Equation(s):
-- \inst2|inst1|inst4~0_combout\ = ( \yxnor~input_o\ & ( !\xxnor~input_o\ ) ) # ( !\yxnor~input_o\ & ( \xxnor~input_o\ ) )

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000111100001111111100001111000000001111000011111111000011110000",
	shared_arith => "off")
-- pragma translate_on
PORT MAP (
	datac => \ALT_INV_xxnor~input_o\,
	datae => \ALT_INV_yxnor~input_o\,
	combout => \inst2|inst1|inst4~0_combout\);

-- Location: LABCELL_X20_Y19_N3
\~QUARTUS_CREATED_GND~I\ : cyclonev_lcell_comb
-- Equation(s):

-- pragma translate_off
GENERIC MAP (
	extended_lut => "off",
	lut_mask => "0000000000000000000000000000000000000000000000000000000000000000",
	shared_arith => "off")
-- pragma translate_on
;
END structure;


