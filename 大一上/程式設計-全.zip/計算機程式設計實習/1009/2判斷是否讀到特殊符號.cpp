#include <stdio.h>
#include <stdlib.h>

int main() {
	char x = ' ';
	int y = 0;
	while (x != '@') {
		if (48 <= x && x <= 57) y++;//48 57
		scanf("%c", &x);
	}
	printf("�@�� %d �Ӫ��ԧB�Ʀr", y);
	system("pause");
	return 0;
}