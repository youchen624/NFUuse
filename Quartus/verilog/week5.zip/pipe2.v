module pipe2 (out, in, clk);
	output out;
	input in , clk;
	
	reg out;
	reg two, one ;
	
	always @(posedge clk)
	begin
		one <=  in;
		two <= one;
		out <= two;
	end
endmodule