`timescale 1ns/100ps
module Testbench();
	reg clk;
	reg in;
	wire out1, out2, out3;
pipe3 u1(.out(out1) , .in(in), .clk(clk));
pipe3 u2(.out(out2) , .in(in), .clk(clk));
pipe3 u3(.out(out3) , .in(in), .clk(clk));
initial begin
	clk =0;
	in = 0;
end
initial begin
	forever #10 clk =~ clk;
end
initial begin
	#11.9 in =1;
	#23 in =0;
	#15.9 in =1;
end

endmodule
